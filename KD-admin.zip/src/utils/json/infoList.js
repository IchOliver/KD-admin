const infoList =[
   {
       id:1,
       title:'Toilet',
       logo:'',
       description:'for companies',
       location:'',
       view_map:'',
       role:''
   },
   {
        id:2,
        title:'Scenes',
        logo:'',
        description:'for companies',
        location:'',
        view_map:'',
        role:''
   },
   {
    id:3,
    title:'Parking',
    logo:'',
    description:'for companies',
    location:'',
    view_map:'',
    role:''
   },
   {
    id:4,
    title:'Parking',
    logo:'',
    description:'for companies',
    location:'',
    view_map:'',
    role:''
   },
   {
    id:5,
    title:'Parking',
    logo:'',
    description:'for companies',
    location:'',
    view_map:'',
    role:''
   },
   {
    id:6,
    title:'Parking',
    logo:'',
    description:'for companies',
    location:'',
    view_map:'',
    role:''
   },

]

export default infoList;