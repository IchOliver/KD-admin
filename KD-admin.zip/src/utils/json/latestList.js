const latestList = [
    {
       id:1,
       title:'Deloitte',
       description:'Teknologi fra et baerekraftsperspektiv',
       time:'10:30',
       room:'C3 349',
       duration:'45min',
       location_image:'',
       view_map:'',
       logo:'',
       permission:''
    },
    {
        id:2,
        title:'Deloitte',
        description:'Teknologi fra et baerekraftsperspektiv',
        time:'10:30',
        room:'C3 349',
        duration:'45min',
        location_image:'',
        view_map:'',
        logo:'',
        permission:''
     },
     {
        id:3,
        title:'Deloitte',
        description:'Teknologi fra et baerekraftsperspektiv',
        time:'10:30',
        room:'C3 349',
        duration:'45min',
        location_image:'',
        view_map:'',
        logo:'',
        permission:''
     },
     {
        id:4,
        title:'Deloitte',
        description:'Teknologi fra et baerekraftsperspektiv',
        time:'10:30',
        room:'C3 349',
        duration:'45min',
        location_image:'',
        view_map:'',
        logo:'',
        permission:''
     },
     {
        id:5,
        title:'Deloitte',
        description:'Teknologi fra et baerekraftsperspektiv',
        time:'10:30',
        room:'C3 349',
        duration:'45min',
        location_image:'',
        view_map:'',
        logo:'',
        permission:''
     },
     {
        id:6,
        title:'Deloitte',
        description:'Teknologi fra et baerekraftsperspektiv',
        time:'10:30',
        room:'C3 349',
        duration:'45min',
        location_image:'',
        view_map:'',
        logo:'',
        permission:''
     },
]

export default latestList;