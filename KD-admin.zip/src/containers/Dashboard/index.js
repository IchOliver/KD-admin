import React,{Fragment} from 'react'
import {Helmet} from 'react-helmet'
import {
 Grid
} from '@material-ui/core'
import Featured from '../../components/Featured'
import LatestEvent from '../../components/LatestEvent'

const Dashboard = props=>{
    
    return (
        <Fragment>
            <Grid container spacing={4}>
                 <Featured/>
                 <Grid item xs={12} >
                    <LatestEvent/>
                 </Grid>
            </Grid>
        </Fragment>
    )
}
export default Dashboard;