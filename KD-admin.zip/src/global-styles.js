import { createGlobalStyle } from 'styled-components';
import 'font-awesome/css/font-awesome.min.css'
import './doc/css/mixin.scss'
import './doc/css/style.scss'

const GlobalStyle = createGlobalStyle`
    
`;

export default GlobalStyle;